from pathlib import Path
import hashlib,re,json
R=Path.cwd()
# Temporary, deterministic forward-only generator. Never rewrites an applied migration.
models={}
def model(table,name,fields,person=False,period=False,states=None):
    d={'id':'uuid','workspaceId':'uuid','createdAt':'time','updatedAt':'time','revision':'int'}
    if person:d.update(personId='uuid',sourceId='uuid')
    d.update(fields)
    if period:d.update(validFrom='time?',validUntil='time?')
    if states:d['status']='enum:'+','.join(states)
    models[table]={'name':name,'fields':d,'person':person,'period':period}
model('talentProfiles','TalentProfile',{'internalSummary':'text'},True,states=['ACTIVE','ARCHIVED'])
model('personRoles','PersonRole',{'roleCode':'text'},True,True,['ACTIVE','INACTIVE'])
model('capabilityDefinitions','CapabilityDefinition',{'code':'text','labelZh':'text','labelEn':'text','aliases':'texts','applicableRoleCodes':'texts','levelSchemeCode':'text?','semanticVersion':'text','schemaVersion':'text'},states=['ACTIVE','INACTIVE'])
model('personCapabilities','PersonCapability',{'personRoleId':'uuid?','capabilityCode':'text','levelCode':'enum:BASIC,WORKING,PROFESSIONAL,FLUENT,NATIVE?'},True,True,['ACTIVE','INACTIVE'])
model('personLanguages','PersonLanguage',dict(languageCode='text',**{k+'LevelCode':'enum:BASIC,WORKING,PROFESSIONAL,FLUENT,NATIVE?' for k in ['speaking','listening','reading','writing']},verifiedAt='time?'),True,True,['ACTIVE','INACTIVE'])
model('talentLocations','TalentLocation',{'locationCode':'text','relationCode':'enum:BASE,SERVICE','verifiedAt':'time?'},True,True,['ACTIVE','INACTIVE'])
model('castingProfiles','CastingProfile',{'hairColorCode':'enum:BLACK,BROWN,BLONDE,RED,GRAY,WHITE,OTHER?','eyeColorCode':'enum:BLACK,BROWN,BLUE,GREEN,GRAY,HAZEL,OTHER?','appearanceObservedOn':'day?','currentMeasurementSetId':'uuid?'},True)
model('measurementSets','MeasurementSet',{'measuredOn':'day','datePrecision':'enum:EXACT_DAY,APPROXIMATE','heightCm':'float?','bustCm':'float?','waistCm':'float?','hipsCm':'float?','shoeSizeValue':'text?','shoeSizeSystem':'enum:EU,US,UK,CN?','clothingSizeValue':'text?','clothingSizeSystem':'enum:INTL,EU,US,UK,CN?','supersedesId':'uuid?'},True,states=['DRAFT','CONFIRMED','SUPERSEDED'])
model('adultEligibilities','AdultEligibility',{'state':'enum:UNKNOWN,SELF_DECLARED_ADULT,VERIFIED_ADULT,RESTRICTED','verifiedByMembershipId':'uuid?','verifiedAt':'time?','validUntil':'time?','evidenceAssetId':'uuid?'},True,states=['ACTIVE','INACTIVE'])
model('organizations','TalentOrganization',{'name':'text','kind':'enum:AGENCY,ISSUER,OTHER','sourceId':'uuid','scopeId':'uuid'},states=['ACTIVE','ARCHIVED'])
model('representations','Representation',{'personRoleId':'uuid?','agencyOrganizationId':'uuid?','agentPersonId':'uuid?','relationCode':'enum:AGENT,AGENCY,MANAGER','territoryCode':'text?'},True,True,['ACTIVE','INACTIVE'])
model('personExternalRefs','PersonExternalRef',{'providerCode':'enum:WECHAT,XIAOHONGSHU,INSTAGRAM,AGENCY_INTERNAL,SUPPLIER_SYSTEM','namespaceCode':'text','issuerOrganizationId':'uuid?','externalKey':'text','state':'enum:OBSERVED,VERIFIED,REVOKED','verifiedAt':'time?'},True)
model('personCredentials','PersonCredential',{'personRoleId':'uuid?','credentialTypeCode':'enum:DRONE_LICENSE,TRANSLATION_CERTIFICATE,DIVING_CERTIFICATE,EQUIPMENT_CERTIFICATE,OTHER','issuerOrganizationId':'uuid?','issuerName':'text?','identifierCiphertext':'text?','maskedIdentifier':'text?','issuedOn':'day?','expiresOn':'day?','evidenceAssetId':'uuid?'},True,states=['UNVERIFIED','VERIFIED','REVOKED'])
model('translatorLanguagePairs','TranslatorLanguagePair',{'personRoleId':'uuid','sourceLanguageCode':'text','targetLanguageCode':'text'},True,states=['ACTIVE','INACTIVE'])
model('translatorServiceModes','TranslatorServiceMode',{'personRoleId':'uuid','modeCode':'enum:BUSINESS_MEETING,ON_SET,ESCORT,CONSECUTIVE,SIMULTANEOUS,WRITTEN'},True,states=['ACTIVE','INACTIVE'])
model('mediaCollections','MediaCollection',{'personRoleId':'uuid?','collectionTypeCode':'enum:MODEL_CARD,POLAROIDS,PORTFOLIO,SHOWREEL,INTRO_VIDEO,OTHER','title':'text'},True,states=['ACTIVE','ARCHIVED'])
model('mediaCollectionTags','MediaCollectionTag',{'collectionId':'uuid','tagCode':'enum:FASHION,BEAUTY,COMMERCIAL,LINGERIE,RUNWAY,LIFESTYLE,INDUSTRIAL,PRODUCT'},True)
model('mediaCollectionItems','MediaCollectionItem',{'personId':'uuid','collectionId':'uuid','assetId':'uuid','orderIndex':'int','caption':'text','featured':'bool'})
model('servicePrincipals','ServicePrincipal',{'displayName':'text','scopeId':'uuid','permissionCodes':'texts','defaultMaintainerMembershipId':'uuid','credentialHash':'text?','keyVersion':'int','expiresAt':'time?','recoveryEpoch':'text'},states=['ACTIVE','REVOKED'])
owners={'personId':'people','talentProfileId':'talentProfiles','personRoleId':'personRoles','personCapabilityId':'personCapabilities','personLanguageId':'personLanguages','talentLocationId':'talentLocations','castingProfileId':'castingProfiles','measurementSetId':'measurementSets','adultEligibilityId':'adultEligibilities','representationId':'representations','personExternalRefId':'personExternalRefs','personCredentialId':'personCredentials','translatorLanguagePairId':'translatorLanguagePairs','translatorServiceModeId':'translatorServiceModes','mediaCollectionId':'mediaCollections','mediaCollectionTagId':'mediaCollectionTags'}
model('fieldProposals','FieldProposal',dict({k:'uuid?' for k in owners},fieldPath='text',proposedValue='json',valueDigest='text',sourceId='uuid',sourceRevision='int',originType='enum:IMPORT,AGENT,AI',actorId='uuid?',servicePrincipalId='uuid?',baseRevision='int',schemaVersion='text',state='enum:PENDING,APPLIED,REJECTED,STALE',decidedAt='time?',decidedById='uuid?'))
model('talentMigrationReviews','TalentMigrationReview',{'personId':'uuid','shortlistItemId':'uuid?','reason':'enum:HEIGHT_SEMANTICS_REQUIRED,SHORTLIST_ROLE_REQUIRED','state':'enum:PENDING,RESOLVED','resolvedAt':'time?','resolvedById':'uuid?'})
existing={'workspaces':'Workspace','people':'Person','sources':'SourceRecord','memberships':'Membership','assets':'MediaAsset','scopes':'AccessScope','shortlistItems':'ShortlistItem','evidence':'FieldEvidence','receipts':'CommandReceipt','audits':'AuditEvent','dictionary':'DictionaryItem'}
names=existing|{t:m['name'] for t,m in models.items()}
def short(s):return s if len(s)<=60 else s[:47]+'_'+hashlib.sha256(s.encode()).hexdigest()[:12]
def parse(t):
    nullable=t.endswith('?');t=t[:-1] if nullable else t
    return t,nullable
PT={'uuid':('String','@db.Uuid','uuid'),'text':('String','@db.Text','text'),'texts':('String[]','','text[]'),'time':('DateTime','@db.Timestamptz(3)','timestamptz(3)'),'day':('String','@db.Text','text'),'float':('Float','@db.DoublePrecision','double precision'),'int':('Int','','integer'),'bool':('Boolean','','boolean'),'json':('Json','@db.JsonB','jsonb')}
def prismafield(k,t):
    t,n=parse(t);p,attr,_=PT['text' if t.startswith('enum:') else t]
    return '  '+k+' '+p+('?' if n else '')+(' @id' if k=='id' else '')+(' '+attr if attr else '')
def tsfield(t):
    t,n=parse(t)
    val=(' | '.join(repr(x) for x in t[5:].split(',')) if t.startswith('enum:') else {'uuid':'string','text':'string','texts':'string[]','time':'string','day':'string','float':'number','int':'number','bool':'boolean','json':'unknown'}[t])
    return val+(' | null' if n else '')
prisma=(R/'prisma/schema.prisma').read_text()
assert 'model TalentProfile {' not in prisma,'Refusing to regenerate existing forward migration'
sql=['-- Talent Domain 2.0 R1 foundation. Additive migration; existing root UUIDs are preserved.','BEGIN;','CREATE EXTENSION IF NOT EXISTS btree_gist;']
extras={}; relation_lines={};relations=[]
def ex(t,line):extras.setdefault(t,[]).append(line)
def check(table,code,expr):sql.append(f'ALTER TABLE "{table}" ADD CONSTRAINT "{short(table+"_td2_"+code)}" CHECK (({expr}) IS TRUE);')
def fk(table,col,target,person=False,special=None):
    fields=['workspaceId',col];refs=['workspaceId','id']
    if person:fields=['workspaceId','personId',col];refs=['workspaceId','personId','id']
    if target=='workspaces':fields=['workspaceId'];refs=['id']
    if special: fields,refs=special
    key=short(table+'_'+col+'_td2_fk');rel=short(names[table]+'_'+col+'_td2')
    nullable=(models[table]['fields'].get(col,'uuid').endswith('?') if table in models else col!='workspaceId')
    if table=='evidence':nullable=col!='sourceId'
    if table=='receipts':nullable=True
    relation_lines.setdefault(table,[]).append(f'  {col}Td2 {names[target]}'+('?' if nullable else '')+f' @relation("{rel}", fields: [{", ".join(fields)}], references: [{", ".join(refs)}], onDelete: NoAction, onUpdate: NoAction, map: "{key}")')
    relation_lines.setdefault(target,[]).append(f'  {rel} {names[table]}[] @relation("{rel}")')
    columns=', '.join('"'+f+'"' for f in fields);references=', '.join('"'+f+'"' for f in refs)
    relations.append(f'ALTER TABLE "{table}" ADD CONSTRAINT "{key}" FOREIGN KEY ({columns}) REFERENCES "{target}" ({references}) ON DELETE NO ACTION ON UPDATE NO ACTION DEFERRABLE INITIALLY DEFERRED;')
for t,m in models.items():
    columns=[]
    for k,typ in m['fields'].items():
        kind,nullable=parse(typ);columnType=PT['text' if kind.startswith('enum:') else kind][2]
        columns.append('  "'+k+'" '+columnType+(' NOT NULL' if not nullable else '')+(' PRIMARY KEY' if k=='id' else ''))
    columns.append(f'  CONSTRAINT "{short(t+"_workspaceId_id_key")}" UNIQUE ("workspaceId", "id")')
    if 'personId' in m['fields'] and t!='fieldProposals':columns.append(f'  CONSTRAINT "{short(t+"_workspaceId_personId_id_key")}" UNIQUE ("workspaceId", "personId", "id")')
    sql.append('CREATE TABLE "'+t+'" (\n'+',\n'.join(columns)+'\n);')
    sql.append(f'CREATE INDEX "{short(t+"_td2_created_idx")}" ON "{t}" ("workspaceId", "createdAt");')
    check(t,'revision','"revision" > 0')
    for k,typ in m['fields'].items():
        kind,nullable=parse(typ)
        if kind.startswith('enum:'):
            options=','.join("'"+v+"'" for v in kind[5:].split(','))
            check(t,k,('"'+k+'" IS NULL OR ' if nullable else '')+f'"{k}" IN ({options})')
        if kind=='day':check(t,k,('"'+k+'" IS NULL OR ' if nullable else '')+f'("{k}" ~ \'^[0-9]{{4}}-[0-9]{{2}}-[0-9]{{2}}$\' AND to_char("{k}"::date,\'YYYY-MM-DD\')="{k}")')
    if m['period']:check(t,'period','"validFrom" IS NULL OR "validUntil" IS NULL OR "validFrom" < "validUntil"')
    fk(t,'workspaceId','workspaces')
    if 'personId' in m['fields'] and t!='fieldProposals':fk(t,'personId','people')
    if 'sourceId' in m['fields']:fk(t,'sourceId','sources')
    if 'scopeId' in m['fields']:fk(t,'scopeId','scopes')
    if 'personRoleId' in m['fields'] and t!='fieldProposals':fk(t,'personRoleId','personRoles',True)
    if 'collectionId' in m['fields']:fk(t,'collectionId','mediaCollections',True)
    if 'assetId' in m['fields']:fk(t,'assetId','assets')
    if 'evidenceAssetId' in m['fields']:fk(t,'evidenceAssetId','assets')
    for key in ['agencyOrganizationId','issuerOrganizationId']:
        if key in m['fields']:fk(t,key,'organizations')
    if 'agentPersonId' in m['fields']:fk(t,'agentPersonId','people')
    for key in ['defaultMaintainerMembershipId','actorId','verifiedByMembershipId','decidedById','resolvedById']:
        if key in m['fields']:fk(t,key,'memberships')
    if 'servicePrincipalId' in m['fields']:fk(t,'servicePrincipalId','servicePrincipals')
    if 'shortlistItemId' in m['fields']:fk(t,'shortlistItemId','shortlistItems')
    if t=='castingProfiles':fk(t,'currentMeasurementSetId','measurementSets',True)
    if t=='measurementSets':fk(t,'supersedesId','measurementSets',True)
# Exactly-one fact owner and append-only supporting evidence.
sql += ['ALTER TABLE "evidence" ALTER COLUMN "personId" DROP NOT NULL, ALTER COLUMN "reviewerId" DROP NOT NULL, ALTER COLUMN "reviewedAt" DROP NOT NULL;']
prisma=prisma.replace('  personId String @db.Uuid\n  fieldPath','  personId String? @db.Uuid\n  fieldPath').replace('  reviewerId String @db.Uuid\n  reviewedAt DateTime @db.Timestamptz(3)','  reviewerId String? @db.Uuid\n  reviewedAt DateTime? @db.Timestamptz(3)').replace('  personIdRef Person @relation("FieldEvidence_','  personIdRef Person? @relation("FieldEvidence_').replace('  reviewerIdRef Membership @relation("FieldEvidence_','  reviewerIdRef Membership? @relation("FieldEvidence_')
for key,target in owners.items():
    if key!='personId':
        ex('evidence',prismafield(key,'uuid?'));sql.append(f'ALTER TABLE "evidence" ADD COLUMN "{key}" uuid;');fk('evidence',key,target)
    fk('fieldProposals',key,target)
for t in ['evidence','fieldProposals']:
    check(t,'exact_owner','num_nonnulls('+','.join('"'+k+'"' for k in owners)+') = 1')
    check(t,'value_digest', '"valueDigest" ~ \'^[a-f0-9]{64}$\'')
check('evidence','review_pair','("reviewerId" IS NULL) = ("reviewedAt" IS NULL)')
for t in ['receipts','audits']:
    ex(t,prismafield('servicePrincipalId','uuid?'));sql.append(f'ALTER TABLE "{t}" ADD COLUMN "servicePrincipalId" uuid;');fk(t,'servicePrincipalId','servicePrincipals')
    if t=='receipts':
        sql.append('ALTER TABLE "receipts" ALTER COLUMN "actorId" DROP NOT NULL;')
        block=re.search(r'model CommandReceipt \{[\s\S]*?\n\}',prisma).group()
        prisma=prisma.replace(block,block.replace('actorId String @db.Uuid','actorId String? @db.Uuid').replace('actorIdRef Membership @relation','actorIdRef Membership? @relation'))
        check(t,'actor','num_nonnulls("actorId","servicePrincipalId") = 1')
        sql.append('CREATE UNIQUE INDEX "receipts_machine_command_key" ON "receipts" ("workspaceId","servicePrincipalId","operation","commandKey") WHERE "servicePrincipalId" IS NOT NULL;')
    else:check(t,'actor','num_nonnulls("actorId","servicePrincipalId") <= 1')
check('fieldProposals','actor','num_nonnulls("actorId","servicePrincipalId")=1')
check('fieldProposals','decision','("state"=\'PENDING\' AND "decidedAt" IS NULL AND "decidedById" IS NULL) OR ("state"<>\'PENDING\' AND "decidedAt" IS NOT NULL AND "decidedById" IS NOT NULL)')
check('fieldProposals','schema','"schemaVersion"=\'once-talent-v2.0.0\' AND "baseRevision">0 AND "sourceRevision">0')
for k,typ in [('personRoleId','uuid?'),('personRoleRevision','int?'),('roleContextState','text?')]:
    ex('shortlistItems',prismafield(k,typ)); sql.append(f'ALTER TABLE "shortlistItems" ADD COLUMN "{k}" '+PT[parse(typ)[0]][2]+';')
fk('shortlistItems','personRoleId','personRoles',True)
check('shortlistItems','role_context','("personRoleId" IS NULL AND "personRoleRevision" IS NULL AND ("roleContextState" IS NULL OR "roleContextState"=\'LEGACY_REVIEW\')) OR ("personRoleId" IS NOT NULL AND "personRoleRevision">0 AND "roleContextState"=\'BOUND\')')
# Cross-table cardinalities and exact business identities.
for t,cols in [('talentProfiles',['personId']),('castingProfiles',['personId']),('capabilityDefinitions',['code']),('mediaCollectionTags',['collectionId','tagCode']),('translatorServiceModes',['personRoleId','modeCode']),('translatorLanguagePairs',['personRoleId','sourceLanguageCode','targetLanguageCode']),('mediaCollectionItems',['collectionId','assetId']),('mediaCollectionItems',['collectionId','orderIndex'])]:
    key=short(t+'_'+'_'.join(cols)+'_td2_unique');cols=['workspaceId']+cols
    sql.append(f'ALTER TABLE "{t}" ADD CONSTRAINT "{key}" UNIQUE ('+', '.join('"'+c+'"' for c in cols)+') DEFERRABLE INITIALLY DEFERRED;')
    # Prisma relations require a nondeferred parent key, added below for profile membership.
    ex(t,'  @@unique(['+', '.join(cols)+f'], map: "{key}")')
# PostgreSQL cannot reference a deferrable unique constraint, so profile member FK uses separate immediate index.
sql.append('CREATE UNIQUE INDEX "talentProfiles_parent_immediate" ON "talentProfiles" ("workspaceId","personId");')
for t in ['personRoles','personCapabilities','talentLocations']:
    fk(t,'personId','talentProfiles',special=(['workspaceId','personId'],['workspaceId','personId']))
# For capability code FK, code must have an immediate unique index too.
sql.append('CREATE UNIQUE INDEX "capabilityDefinitions_code_immediate" ON "capabilityDefinitions" ("workspaceId","code");')
fk('personCapabilities','capabilityCode','capabilityDefinitions',special=(['workspaceId','capabilityCode'],['workspaceId','code']))
for t,keys,where in [('personRoles',['personId','roleCode'],''),('personLanguages',['personId','languageCode'],''),('talentLocations',['personId'],' AND "relationCode"=\'BASE\'')]:
    expr=['"workspaceId" WITH =']+['"'+k+'" WITH =' for k in keys]+['tstzrange("validFrom","validUntil",\'[)\') WITH &&']
    sql.append(f'ALTER TABLE "{t}" ADD CONSTRAINT "{short(t+"_active_period_td2")}" EXCLUDE USING gist ('+', '.join(expr)+f') WHERE ("status"=\'ACTIVE\'{where}) DEFERRABLE INITIALLY DEFERRED;')
sql.append('CREATE UNIQUE INDEX "adultEligibilities_active_td2" ON "adultEligibilities" ("workspaceId","personId") WHERE "status"=\'ACTIVE\';')
sql.append('CREATE UNIQUE INDEX "personExternalRefs_exact_td2" ON "personExternalRefs" ("workspaceId","providerCode","namespaceCode",COALESCE("issuerOrganizationId",\'00000000-0000-0000-0000-000000000000\'::uuid),"externalKey") WHERE "state"<>\'REVOKED\';')
check('personExternalRefs','external_key','length("externalKey") BETWEEN 1 AND 300 AND length("namespaceCode")<=120')
check('personExternalRefs','verified','"state"<>\'VERIFIED\' OR "verifiedAt" IS NOT NULL')
check('representations','representative','num_nonnulls("agencyOrganizationId","agentPersonId")>=1 AND ("agentPersonId" IS NULL OR "agentPersonId"<>"personId")')
check('measurementSets','shoe','("shoeSizeValue" IS NULL)=("shoeSizeSystem" IS NULL)')
check('measurementSets','clothing','("clothingSizeValue" IS NULL)=("clothingSizeSystem" IS NULL)')
for field,lo,hi in [('heightCm',30,260),('bustCm',20,250),('waistCm',20,250),('hipsCm',20,250)]:check('measurementSets',field,f'"{field}" IS NULL OR "{field}" BETWEEN {lo} AND {hi}')
check('measurementSets','has_value','num_nonnulls("heightCm","bustCm","waistCm","hipsCm","shoeSizeValue","clothingSizeValue")>=1')
check('adultEligibilities','verified','"state"<>\'VERIFIED_ADULT\' OR ("verifiedAt" IS NOT NULL AND "verifiedByMembershipId" IS NOT NULL)')
check('personCredentials','cipher_pair','("identifierCiphertext" IS NULL)=("maskedIdentifier" IS NULL)')
check('personCredentials','dates','"issuedOn" IS NULL OR "expiresOn" IS NULL OR "issuedOn"<= "expiresOn"')
check('personCredentials','issuer','"issuerOrganizationId" IS NOT NULL OR ("issuerName" IS NOT NULL AND length("issuerName")>0)')
check('mediaCollectionItems','order','"orderIndex">=0')
check('translatorLanguagePairs','direction','"sourceLanguageCode"<>"targetLanguageCode"')
check('servicePrincipals','credential','"keyVersion">0 AND (("status"=\'ACTIVE\' AND "credentialHash" ~ \'^[a-f0-9]{64}$\') OR ("status"=\'REVOKED\' AND "credentialHash" IS NULL))')
check('servicePrincipals','permissions','"permissionCodes" <@ ARRAY[\'records.read\',\'sources.read\',\'talent.propose\',\'talent.fact.write\']::text[] AND cardinality("permissionCodes")>0')
# Generate all relations AFTER all columns and all referenced immediate keys exist.
sql+=relations
# Identity/talent separation: old columns remain migration inputs until explicit retirement.
sql.append('''DO $$ DECLARE c record; BEGIN
 FOR c IN SELECT conname FROM pg_constraint WHERE conrelid='"people"'::regclass AND contype='c' AND pg_get_constraintdef(oid) LIKE '%cardinality(roles)%' LOOP
 EXECUTE format('ALTER TABLE "people" DROP CONSTRAINT %I',c.conname); END LOOP;
END $$;''')
check('people','role_compat','cardinality("roles") BETWEEN 0 AND 10')
# Body-value changes to confirmed measurements are forbidden. Parent relinking is an explicit maintenance operation.
sql.append('''CREATE FUNCTION once_td2_measurement_immutable() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN
 IF OLD."status" IN ('CONFIRMED','SUPERSEDED') AND
 (to_jsonb(NEW)-ARRAY['personId','status','updatedAt','revision','supersedesId']) IS DISTINCT FROM
 (to_jsonb(OLD)-ARRAY['personId','status','updatedAt','revision','supersedesId']) THEN
 RAISE EXCEPTION 'confirmed measurements are immutable; create a new measured version'; END IF;
 RETURN NEW; END $$;
CREATE TRIGGER measurementSets_td2_immutable BEFORE UPDATE ON "measurementSets" FOR EACH ROW EXECUTE FUNCTION once_td2_measurement_immutable();''')
# Typed snapshot migration: no fabricated language levels, measurement dates or identity deduplication.
sql += ['''INSERT INTO "talentProfiles" ("id","workspaceId","createdAt","updatedAt","revision","personId","sourceId","internalSummary","status")
 SELECT gen_random_uuid(),"workspaceId","createdAt","updatedAt",1,"id","sourceId",'','ACTIVE' FROM "people" WHERE "status"<>'ERASED' AND cardinality("roles")>0;''', '''INSERT INTO "personRoles" ("id","workspaceId","createdAt","updatedAt","revision","personId","sourceId","roleCode","validFrom","validUntil","status")
 SELECT gen_random_uuid(),p."workspaceId",p."createdAt",p."updatedAt",1,p."id",p."sourceId",r,NULL,NULL,'ACTIVE' FROM "people" p CROSS JOIN LATERAL (SELECT DISTINCT unnest(p."roles") r) x WHERE p."status"<>'ERASED';''', '''INSERT INTO "capabilityDefinitions" ("id","workspaceId","createdAt","updatedAt","revision","code","labelZh","labelEn","aliases","applicableRoleCodes","levelSchemeCode","semanticVersion","schemaVersion","status")
 SELECT gen_random_uuid(),"workspaceId","createdAt","updatedAt",1,"code","labelZh","labelEn",ARRAY[]::text[],ARRAY[]::text[],NULL,'1.0.0','once-talent-v2.0.0',"status" FROM "dictionary" WHERE "namespace"='skill';''', '''INSERT INTO "personCapabilities" ("id","workspaceId","createdAt","updatedAt","revision","personId","sourceId","personRoleId","capabilityCode","levelCode","validFrom","validUntil","status")
 SELECT gen_random_uuid(),p."workspaceId",p."createdAt",p."updatedAt",1,p."id",p."sourceId",NULL,s,NULL,NULL,NULL,'ACTIVE' FROM "people" p CROSS JOIN LATERAL (SELECT DISTINCT unnest(p."skillCodes") s) x JOIN "talentProfiles" t ON t."workspaceId"=p."workspaceId" AND t."personId"=p."id";''', '''INSERT INTO "personLanguages" ("id","workspaceId","createdAt","updatedAt","revision","personId","sourceId","languageCode","speakingLevelCode","listeningLevelCode","readingLevelCode","writingLevelCode","verifiedAt","validFrom","validUntil","status")
 SELECT gen_random_uuid(),p."workspaceId",p."createdAt",p."updatedAt",1,p."id",p."sourceId",l,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ACTIVE' FROM "people" p CROSS JOIN LATERAL (SELECT DISTINCT unnest(p."languageCodes") l) x WHERE p."status"<>'ERASED';''', '''INSERT INTO "talentLocations" ("id","workspaceId","createdAt","updatedAt","revision","personId","sourceId","locationCode","relationCode","verifiedAt","validFrom","validUntil","status")
 SELECT gen_random_uuid(),p."workspaceId",p."createdAt",p."updatedAt",1,p."id",p."sourceId",p."cityCode",'BASE',NULL,NULL,NULL,'ACTIVE' FROM "people" p JOIN "talentProfiles" t ON t."workspaceId"=p."workspaceId" AND t."personId"=p."id" WHERE p."cityCode" IS NOT NULL;''', '''INSERT INTO "talentMigrationReviews" ("id","workspaceId","createdAt","updatedAt","revision","personId","shortlistItemId","reason","state","resolvedAt","resolvedById")
 SELECT gen_random_uuid(),"workspaceId",now(),now(),1,"id",NULL,'HEIGHT_SEMANTICS_REQUIRED','PENDING',NULL,NULL FROM "people" WHERE "status"<>'ERASED' AND "heightCm" IS NOT NULL;''', '''UPDATE "shortlistItems" i SET "personRoleId"=r.id,"personRoleRevision"=1,"roleContextState"='BOUND' FROM
 (SELECT "workspaceId","personId",min("id"::text)::uuid id FROM "personRoles" WHERE "status"='ACTIVE' GROUP BY "workspaceId","personId" HAVING count(*)=1) r
 WHERE r."workspaceId"=i."workspaceId" AND r."personId"=i."personId";''', '''UPDATE "shortlistItems" SET "roleContextState"='LEGACY_REVIEW' WHERE "personRoleId" IS NULL;''', '''INSERT INTO "talentMigrationReviews" ("id","workspaceId","createdAt","updatedAt","revision","personId","shortlistItemId","reason","state","resolvedAt","resolvedById")
 SELECT gen_random_uuid(),"workspaceId",now(),now(),1,"personId","id",'SHORTLIST_ROLE_REQUIRED','PENDING',NULL,NULL FROM "shortlistItems" WHERE "personRoleId" IS NULL;''']
sql.append('COMMIT;')
# Assemble Prisma model and inverse relation definitions, preserving all legacy definitions.
for t,m in models.items():
    body=[prismafield(k,v) for k,v in m['fields'].items()]+relation_lines.get(t,[])+extras.get(t,[])+['  @@unique([workspaceId, id])']
    if 'personId' in m['fields'] and t!='fieldProposals':body.append('  @@unique([workspaceId, personId, id])')
    body+=['  @@index([workspaceId, createdAt], map: "'+short(t+'_td2_created_idx')+'")','  @@map("'+t+'")']
    prisma+='\nmodel '+m['name']+' {\n'+'\n'.join(body)+'\n}\n'
for t in existing:
    add=extras.get(t,[])+relation_lines.get(t,[])
    if add:prisma=prisma.replace('model '+names[t]+' {','model '+names[t]+' {\n'+'\n'.join(add),1)
# One relation-name collision: talent membership and person identity use different relation names.
# Replace the generated duplicate personIdTd2 for the membership relation only, preserving SQL refs.
for t in ['personRoles','personCapabilities','talentLocations']:
    name=names[t]
    block=re.search(r'model '+name+r' \{[\s\S]*?\n\}',prisma).group()
    block2=block.replace('personIdTd2 TalentProfile','talentProfileTd2 TalentProfile').replace(f'@relation("{name}_personId_td2", fields: [workspaceId, personId], references: [workspaceId, personId]',f'@relation("{name}_talentProfile_td2", fields: [workspaceId, personId], references: [workspaceId, personId]').replace(f'map: "{t}_personId_td2_fk")',f'map: "{t}_talentProfile_td2_fk")')
    # Restore the Person relation constraint name, changed by the broad map replacement.
    block2=block2.replace(f'Person @relation("{name}_personId_td2", fields: [workspaceId, personId], references: [workspaceId, id], onDelete: NoAction, onUpdate: NoAction, map: "{t}_talentProfile_td2_fk")',f'Person @relation("{name}_personId_td2", fields: [workspaceId, personId], references: [workspaceId, id], onDelete: NoAction, onUpdate: NoAction, map: "{t}_personId_td2_fk")')
    prisma=prisma.replace(block,block2)
    profile=re.search(r'model TalentProfile \{[\s\S]*?\n\}',prisma).group()
    prisma=prisma.replace(profile,profile.replace(f'{name}_personId_td2 {name}[] @relation("{name}_personId_td2")',f'{name}_talentProfile_td2 {name}[] @relation("{name}_talentProfile_td2")'))
    sql=[line.replace(f'"{t}_personId_td2_fk"',f'"{t}_talentProfile_td2_fk"') if f'REFERENCES "talentProfiles"' in line and f'ALTER TABLE "{t}"' in line else line for line in sql]
(R/'prisma/schema.prisma').write_text(prisma)
mig=R/'prisma/migrations/202609270001_talent_domain_v2';mig.mkdir();(mig/'migration.sql').write_text('\n'.join(sql)+'\n')
# Core type definitions and persistence delegates.
ts="import type { Base } from './model.ts';\nexport const TALENT_SCHEMA_VERSION = 'once-talent-v2.0.0' as const;\n"
for t,m in models.items():
    ts+='export interface '+m['name']+' extends Base {\n'+''.join('    '+k+': '+tsfield(v)+';\n' for k,v in m['fields'].items() if k not in ['id','workspaceId','createdAt','updatedAt','revision'])+'}\n'
ts+='export interface TalentV2Tables {\n'+''.join('    '+t+': '+m['name']+';\n' for t,m in models.items())+'}\n'
ts+='export const TALENT_V2_TABLES = '+json.dumps(list(models))+' as const;\n'
ts+='export const TALENT_FACT_TABLES = '+json.dumps([t for t,m in models.items() if m['person']])+' as const;\n'
ts+='export const TALENT_OWNER_TABLES = '+json.dumps(owners)+' as const;\nexport type TalentOwnerField = keyof typeof TALENT_OWNER_TABLES;\n'
ts+='export type TalentOwnerRefs = {[K in TalentOwnerField]: string | null};\n'
ts+='export const TALENT_OWNER_EMPTY: TalentOwnerRefs = '+json.dumps({k:None for k in owners})+';\n'
(R/'packages/core/src/talent-v2-model.ts').write_text(ts)
p=R/'packages/core/src/model.ts';s=p.read_text();s="import type { TalentV2Tables, TalentOwnerRefs } from './talent-v2-model.ts';\n"+s
s=s.replace('export interface TableMap {','export interface TableMap extends TalentV2Tables {').replace("| ExtraPermission;", "| 'talent.propose' | 'talent.fact.write' | ExtraPermission;")
s=s.replace('export interface Actor {','export interface Actor {\n    actorKind?: \'HUMAN\' | \'MACHINE\';\n    servicePrincipalId?: string;\n    machineScopeId?: string;')
s=s.replace('export interface FieldEvidence extends Base {\n    personId: string;','export interface FieldEvidence extends Base, Partial<TalentOwnerRefs> {\n    personId: string | null;').replace('    reviewerId: string;\n    reviewedAt: string;','    reviewerId: string | null;\n    reviewedAt: string | null;')
s=s.replace('export interface CommandReceipt extends Base {\n    actorId: string;','export interface CommandReceipt extends Base {\n    servicePrincipalId?: string | null;\n    actorId: string | null;').replace('export interface AuditEvent extends Base {','export interface AuditEvent extends Base {\n    servicePrincipalId?: string | null;')
p.write_text(s)
p=R/'apps/api/src/prisma-store.ts';s=p.read_text();s=s.replace('const DELEGATE: Record<Table, string> = {','const DELEGATE: Record<Table, string> = { '+', '.join(t+": '"+m['name'][0].lower()+m['name'][1:]+"'" for t,m in models.items())+', ');s=s.replace("'approvedAt']);","'approvedAt','verifiedAt','resolvedAt']);")
s=s.replace("DATES.has(key) && typeof value === 'string' ? new Date(value) : value", "key === 'proposedValue' && value === null ? Prisma.JsonNull : DATES.has(key) && typeof value === 'string' ? new Date(value) : value")
p.write_text(s)
p=R/'tests/support/memory-store.ts';s=p.read_text().replace("const tables: Table[] = [", "const tables: Table[] = ["+', '.join(repr(t) for t in models)+', ');p.write_text(s)
# Existing human evidence maps now guard the nullable typed owner.
p=R/'packages/core/src/talent-search.ts';s=p.read_text().replace('verifiedIds.add(e.personId)','if (e.personId) verifiedIds.add(e.personId)');p.write_text(s)
(R/'artifacts/td2-model-contract.json').write_text(json.dumps(models,ensure_ascii=False,indent=2)+'\n')
print('Generated',len(models),'typed models; forward migration and core delegates')

# Review hardening before first application.
p=R/'prisma/migrations/202609270001_talent_domain_v2/migration.sql';s=p.read_text()
s=re.sub(r'(ALTER TABLE "(?:talentProfiles|capabilityDefinitions)" ADD CONSTRAINT [^\n]+) DEFERRABLE INITIALLY DEFERRED;',r'\1;',s)
s=re.sub(r'CREATE UNIQUE INDEX "(?:talentProfiles_parent_immediate|capabilityDefinitions_code_immediate)"[^\n]+\n','',s)
s=s.replace("IF OLD.\"status\" IN ('CONFIRMED','SUPERSEDED') AND\n", "IF OLD.\"status\" IN ('CONFIRMED','SUPERSEDED') AND NEW.\"status\" = 'DRAFT' THEN RAISE EXCEPTION 'confirmed measurement cannot return to draft'; END IF;\n IF OLD.\"status\" IN ('CONFIRMED','SUPERSEDED') AND\n")
p.write_text(s)
p=R/'packages/core/src/talent-search.ts';s=p.read_text().replace("for (const evidence of evidenceRows) {", "for (const evidence of evidenceRows) {\n            if (!evidence.personId || !evidence.reviewedAt) continue;")
s=s.replace('if (!source || !visibility.source(source)','if (!evidence.reviewedAt || !source || !visibility.source(source)');p.write_text(s)
